# version

* 基于 SDK 8.3.4版本：
  * ING918可以正常使用；
  * ING916缺少正常的board.c支持代码，暂无法使用；