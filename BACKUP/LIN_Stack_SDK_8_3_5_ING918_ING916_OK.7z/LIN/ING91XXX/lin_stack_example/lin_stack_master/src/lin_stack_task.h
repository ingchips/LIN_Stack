#ifndef __LIN_STACK_TASK_H__
#define __LIN_STACK_TASK_H__
#include <stdio.h>
#include <string.h>
#include <stdint.h>

void BTNPORT_Handler(uint8_t num);
void lin_stack_task(void);

#endif

