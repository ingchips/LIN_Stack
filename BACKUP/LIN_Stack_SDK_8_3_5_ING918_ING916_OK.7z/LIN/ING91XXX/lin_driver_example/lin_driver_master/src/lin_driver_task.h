#ifndef __LIN_DRIVER_TASK_H__
#define __LIN_DRIVER_TASK_H__
#include <stdio.h>
#include <string.h>
#include <stdint.h>

void BTNPORT_Handler(uint8_t num);
void lin_drv_task(void);

#endif

